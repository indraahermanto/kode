<title>Siimanto | Setup</title>
<div class="container" style="min-height:550px">
	<br/>
	<div>
		<h2 class="text-center">Setup</h2>
		<br/>
		<div>
			<form action="" method="POST">
			<div class="row">
			<div class="form-group col-md-2"></div>
				<div class="form-group col-md-4">
					<label for="">Saldo Cash</label>
					<input class="form-control" type="text" name="SaldoBank" placeholder="Saldo Bank">
				</div>
				<div class="form-group col-md-4">
					<label for="">Saldo Bank</label>
					<input class="form-control" type="text" name="SaldoCash" placeholder="Saldo Cash">
				</div>
			<div class="form-group col-md-2"></div>
			</div>
			<div class="row">
			<div class="form-group col-md-2"></div>
				<div class="form-group col-md-4">
					<label for="">Saldo Toped</label>
					<input class="form-control" type="text" name="SaldoToped" placeholder="Saldo Toped">
				</div>
				<div class="form-group col-md-4">
					<label for="">Saldo Toped</label>
					<input class="form-control" type="text" name="SaldoToped" placeholder="Saldo Toped">
				</div>
			<div class="form-group col-md-2"></div>
			</div>
			<div class="row">
			<div class="form-group col-md-2"></div>
				<div class="form-group col-md-4">
					<label for="">Saldo Cash</label>
					<input class="form-control" type="text" name="SaldoBank" placeholder="Saldo Bank">
				</div>
				<div class="form-group col-md-4">
					<label for="">Saldo Bank</label>
					<input class="form-control" type="text" name="SaldoCash" placeholder="Saldo Cash">
				</div>
			<div class="form-group col-md-2"></div>
			</div>
			</form>
		</div>
	</div>
	<br/><br/><br/>
	<div class="row">
	</div>
	<br/><br/><br/>
</div>