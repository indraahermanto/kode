
<div class="navbar navbar-default">
	<div class="container">
		<h6 class="footer text-right">Server process time: <strong>{elapsed_time}</strong> seconds</h6>
		<h5 class="footer text-center">Copyright Siimanto.com 
			<span class="glyphicon glyphicon-copyright-mark" aria-hidden="true"></span> 2015</h5>
	</div>
</div>


</body>
</html>