<title>Siimanto | Register</title>
<div class="container" style="min-height:550px">
<div class="col-md-2"></div>
	<div class="col-md-8">
		<h3><?php echo 'Thanks for registering '.$firstname."!" ?></h3>
		<p>Please check your email to activate this account.</p>
	</div>
<div class="col-md-2"></div>
</div>