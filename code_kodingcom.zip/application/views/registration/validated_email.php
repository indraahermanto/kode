<title>Siimanto | Register</title>
<div class="container" style="min-height:550px">
<div class="col-md-2"></div>
	<div class="col-md-8">
		<h3><?php echo 'Activating account '.$email_address." succeed!" ?></h3>
		
	</div>
<div class="col-md-2"></div>
</div>